﻿using System.Net.Http.Json;

[Collection("Integration Tests")]
public class DonationIntegrationTests
{
    private readonly HttpClient _client;

    public DonationIntegrationTests(IntegrationTestFixture fixture)
    {
        _client = fixture.Client;
    }

    [Fact]
    public async Task MakeAndRetrieveDonations_ShouldReturnDonationsList()
    {
        // Arrange - Make a donation
        var donation = new Donation
        {
            UserId = 1,
            ResourceType = "Water",
            Quantity = 50,
            Location = "City A"
        };

        // Act - Make donation
        var donationResponse = await _client.PostAsJsonAsync("/api/donation", donation);
        donationResponse.EnsureSuccessStatusCode();

        // Act - Retrieve donations
        var getResponse = await _client.GetAsync("/api/donation");
        getResponse.EnsureSuccessStatusCode();
        var donations = await getResponse.Content.ReadFromJsonAsync<List<Donation>>();

        // Assert
        Assert.NotEmpty(donations);
        Assert.Contains(donations, d => d.ResourceType == "Water" && d.Quantity == 50);
    }
}
