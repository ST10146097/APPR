﻿using System.Net.Http.Json;

[Collection("Integration Tests")]
public class IncidentIntegrationTests
{
    private readonly HttpClient _client;

    public IncidentIntegrationTests(IntegrationTestFixture fixture)
    {
        _client = fixture.Client;
    }

    [Fact]
    public async Task ReportAndRetrieveIncidents_ShouldReturnIncidentsList()
    {
        // Arrange - Report an incident
        var incident = new Incident
        {
            UserId = 1,
            IncidentTitle = "Power Outage",
            IncidentDescription = "There is a major power outage in City B.",
            IncidentType = "Infrastructure",
            Location = "City B"
        };

        // Act - Report incident
        var reportResponse = await _client.PostAsJsonAsync("/api/incident", incident);
        reportResponse.EnsureSuccessStatusCode();

        // Act - Retrieve incidents
        var getResponse = await _client.GetAsync("/api/incident");
        getResponse.EnsureSuccessStatusCode();
        var incidents = await getResponse.Content.ReadFromJsonAsync<List<Incident>>();

        // Assert
        Assert.NotEmpty(incidents);
        Assert.Contains(incidents, i => i.IncidentTitle == "Power Outage");
    }
}
