﻿using System.Net;
using System.Net.Http.Json;
using System.Threading.Tasks;
using WebApp.Models;
using Xunit;

[Collection("Integration Tests")]
public class UserIntegrationTests
{
    private readonly HttpClient _client;

    public UserIntegrationTests(IntegrationTestFixture fixture)
    {
        _client = fixture.Client;
    }

    [Fact]
    public async Task RegisterAndLoginUser_ShouldReturnSuccess()
    {
        // Arrange - Register a user
        var newUser = new User
        {
            Username = "integrationUser",
            Email = "integration@example.com",
            PasswordHash = "Password123!",
            FirstName = "Integration",
            LastName = "Test"
        };

        // Act - Register
        var registerResponse = await _client.PostAsJsonAsync("/api/user/register", newUser);
        registerResponse.EnsureSuccessStatusCode();

        // Arrange - Login with UserLoginDTO
        var loginDto = new UserLoginDTO
        {
            Username = newUser.Username,
            Password = "Password123!"
        };

        // Act - Login
        var loginResponse = await _client.PostAsJsonAsync("/api/user/login", loginDto);

        // Assert
        Assert.Equal(HttpStatusCode.OK, loginResponse.StatusCode);
    }
}
