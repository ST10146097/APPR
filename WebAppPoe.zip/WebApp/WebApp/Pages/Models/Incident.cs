﻿public class Incident
{
    public int IncidentId { get; set; }
    public int UserId { get; set; }
    public string IncidentTitle { get; set; }
    public string IncidentDescription { get; set; }
    public string IncidentType { get; set; }
    public string Location { get; set; }
    public DateTime ReportedAt { get; set; } = DateTime.Now;
    public string Status { get; set; } = "Pending";

    public User User { get; set; }
}
