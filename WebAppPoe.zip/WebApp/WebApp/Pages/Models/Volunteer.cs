﻿public class Volunteer
{
    public int VolunteerId { get; set; }
    public int UserId { get; set; }
    public int? TaskId { get; set; }
    public DateTime SignUpDate { get; set; } = DateTime.Now;
    public string Contribution { get; set; }

    public User User { get; set; }
    public Task Task { get; set; }
}
