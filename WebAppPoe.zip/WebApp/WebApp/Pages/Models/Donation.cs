﻿public class Donation
{
    public int DonationId { get; set; }
    public int UserId { get; set; }
    public string ResourceType { get; set; }
    public int Quantity { get; set; }
    public string Location { get; set; }
    public DateTime DonationDate { get; set; } = DateTime.Now;
    public string Status { get; set; } = "Pending";

    public User User { get; set; }
}
