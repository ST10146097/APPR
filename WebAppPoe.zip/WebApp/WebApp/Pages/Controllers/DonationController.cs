﻿using Microsoft.AspNetCore.Mvc;
using WebApp.Data;
using System.Linq; // For LINQ query syntax
using Microsoft.EntityFrameworkCore; // For EF Core async methods like ToListAsync


[ApiController]
[Route("api/[controller]")]
public class DonationController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public DonationController(ApplicationDbContext context)
    {
        _context = context;
    }

    // Create a donation
    [HttpPost]
    public async Task<IActionResult> MakeDonation([FromBody] Donation donation)
    {
        _context.Donations.Add(donation);
        await _context.SaveChangesAsync();
        return Ok(new { message = "Donation made successfully." });
    }

    // Get all donations
    [HttpGet]
    public async Task<IActionResult> GetDonations()
    {
        var donations = await _context.Donations.ToListAsync();
        return Ok(donations);
    }
}
