﻿using Microsoft.AspNetCore.Mvc;
using WebApp.Data;
using System.Linq; // For LINQ query syntax
using Microsoft.EntityFrameworkCore; // For EF Core async methods like ToListAsync


[ApiController]
[Route("api/[controller]")]
public class IncidentController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public IncidentController(ApplicationDbContext context)
    {
        _context = context;
    }

    // Submit an incident
    [HttpPost]
    public async Task<IActionResult> ReportIncident([FromBody] Incident incident)
    {
        _context.Incidents.Add(incident);
        await _context.SaveChangesAsync();
        return Ok(new { message = "Incident reported successfully." });
    }

    // Get all incidents
    [HttpGet]
    public async Task<IActionResult> GetIncidents()
    {
        var incidents = await _context.Incidents.ToListAsync();
        return Ok(incidents);
    }
}
