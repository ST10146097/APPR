﻿using Microsoft.AspNetCore.Mvc;
using WebApp.Data;
using System.Linq; // For LINQ query syntax
using Microsoft.EntityFrameworkCore; // For EF Core async methods like ToListAsync


[ApiController]
[Route("api/[controller]")]
public class VolunteerController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public VolunteerController(ApplicationDbContext context)
    {
        _context = context;
    }

    // Sign up as a volunteer
    [HttpPost]
    public async Task<IActionResult> SignUp([FromBody] Volunteer volunteer)
    {
        _context.Volunteers.Add(volunteer);
        await _context.SaveChangesAsync();
        return Ok(new { message = "Volunteer signed up successfully." });
    }

    // Get all volunteers
    [HttpGet]
    public async Task<IActionResult> GetVolunteers()
    {
        var volunteers = await _context.Volunteers.ToListAsync();
        return Ok(volunteers);
    }
}
