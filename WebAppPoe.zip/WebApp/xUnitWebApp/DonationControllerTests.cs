﻿public class DonationControllerTests
{
    private readonly ApplicationDbContext _context;
    private readonly DonationController _controller;

    public DonationControllerTests()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDatabase")
            .Options;
        _context = new ApplicationDbContext(options);
        _controller = new DonationController(_context);
    }

    [Fact]
    public async Task MakeDonation_ShouldReturnOkResult()
    {
        // Arrange
        var donation = new Donation
        {
            UserId = 1,
            ResourceType = "Food",
            Quantity = 10,
            Location = "Location A"
        };

        // Act
        var result = await _controller.MakeDonation(donation);

        // Assert
        Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public async Task GetDonations_ShouldReturnAllDonations()
    {
        // Act
        var result = await _controller.GetDonations();
        var okResult = result as OkObjectResult;

        // Assert
        Assert.NotNull(okResult);
        Assert.IsType<OkObjectResult>(result);
        Assert.IsAssignableFrom<IEnumerable<Donation>>(okResult.Value);
    }
}
