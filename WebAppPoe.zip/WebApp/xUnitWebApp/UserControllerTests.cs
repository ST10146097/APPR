﻿using Moq;
using WebApp.Models;

public class UserControllerTests
{
    private readonly ApplicationDbContext _context;
    private readonly UserController _controller;

    public UserControllerTests()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDatabase")
            .Options;
        _context = new ApplicationDbContext(options);
        _controller = new UserController(_context);
    }

    [Fact]
    public async Task Register_ShouldReturnOkResult()
    {
        // Arrange
        var user = new User
        {
            Username = "testuser",
            Email = "testuser@example.com",
            PasswordHash = "password",
            FirstName = "Test",
            LastName = "User"
        };

        // Act
        var result = await _controller.Register(user);

        // Assert
        Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public async Task Login_WithValidCredentials_ShouldReturnOkResult()
    {
        // Arrange
        var user = new User
        {
            Username = "testuser",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("password")
        };
        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        var loginDTO = new UserLoginDTO
        {
            Username = "testuser",
            Password = "password"
        };

        // Act
        var result = await _controller.Login(loginDTO);

        // Assert
        Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public async Task Login_WithInvalidCredentials_ShouldReturnUnauthorized()
    {
        // Arrange
        var loginDTO = new UserLoginDTO
        {
            Username = "invaliduser",
            Password = "wrongpassword"
        };

        // Act
        var result = await _controller.Login(loginDTO);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(result);
    }
}
