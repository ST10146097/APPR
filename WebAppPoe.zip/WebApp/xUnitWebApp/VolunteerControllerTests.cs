﻿public class VolunteerControllerTests
{
    private readonly ApplicationDbContext _context;
    private readonly VolunteerController _controller;

    public VolunteerControllerTests()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDatabase")
            .Options;
        _context = new ApplicationDbContext(options);
        _controller = new VolunteerController(_context);
    }

    [Fact]
    public async Task SignUp_ShouldReturnOkResult()
    {
        // Arrange
        var volunteer = new Volunteer
        {
            UserId = 1,
            Contribution = "Contributing to task A"
        };

        // Act
        var result = await _controller.SignUp(volunteer);

        // Assert
        Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public async Task GetVolunteers_ShouldReturnAllVolunteers()
    {
        // Act
        var result = await _controller.GetVolunteers();
        var okResult = result as OkObjectResult;

        // Assert
        Assert.NotNull(okResult);
        Assert.IsType<OkObjectResult>(result);
        Assert.IsAssignableFrom<IEnumerable<Volunteer>>(okResult.Value);
    }
}
