﻿public class IncidentControllerTests
{
    private readonly ApplicationDbContext _context;
    private readonly IncidentController _controller;

    public IncidentControllerTests()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDatabase")
            .Options;
        _context = new ApplicationDbContext(options);
        _controller = new IncidentController(_context);
    }

    [Fact]
    public async Task ReportIncident_ShouldReturnOkResult()
    {
        // Arrange
        var incident = new Incident
        {
            UserId = 1,
            IncidentTitle = "Test Incident",
            IncidentDescription = "Description",
            IncidentType = "Type A",
            Location = "Location A"
        };

        // Act
        var result = await _controller.ReportIncident(incident);

        // Assert
        Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public async Task GetIncidents_ShouldReturnAllIncidents()
    {
        // Act
        var result = await _controller.GetIncidents();
        var okResult = result as OkObjectResult;

        // Assert
        Assert.NotNull(okResult);
        Assert.IsType<OkObjectResult>(result);
        Assert.IsAssignableFrom<IEnumerable<Incident>>(okResult.Value);
    }
}
